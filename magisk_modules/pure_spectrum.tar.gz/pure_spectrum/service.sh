#!/system/bin/sh

MODDIR=${0%/*}

# write & lock
function write() {
    chmod 0666 $1
    echo -n $2 > $1
    chmod 0444 $1
}

# Enable Spectrum support
setprop spectrum.support 1

# Abort if kernel does not support "interactive" governors
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors | grep "interactive" &>/dev/null || {
    setprop spectrum.support ""
    exit 1
}

cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies | grep "1843200" &>/dev/null && {
    # OC
    is_oc=true
    powercfg_file=${MODDIR}/common/powercfg-660.sh
} || {
    # Non-OC
    is_oc=false
    powercfg_file=${MODDIR}/common/powercfg-636.sh
}

# Need to be executed at least once each boot
boot_run_once=false

spectrum_mode=$(getprop persist.spectrum.profile)
[ -z "$spectrum_mode" ] && setprop persist.spectrum.profile 0

# Waiting for some boot scripts to execute
sleep 20

(
while true; do
    sleep 3
    if $boot_run_once; then
        [ "$(getprop persist.spectrum.profile)" == "$spectrum_mode" ] && continue
    else
        boot_run_once=true
    fi
    spectrum_mode=$(getprop persist.spectrum.profile)
    case "$spectrum_mode" in
        # Balance
        "0") {
            sh $powercfg_file "balance"
            echo "0" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
        };;
        # Performance
        "1") {
            sh $powercfg_file "performance"
            echo "1" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
        };;
        # Battery
        "2") {
            sh $powercfg_file "powersave"
            echo "0" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
        };;
        # Gaming
        "3") {
            # Do NOT use "performance" governors with OC (for safe)
            $is_oc && sh $powercfg_file "fast" || {
                # Use "performance" governors for best performance
                write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor "performance"
                write /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor "performance"
            }
            echo "3" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
        };;
        # else do nothing
    esac
done
) &
