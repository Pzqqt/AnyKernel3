#!/sbin/sh

MODDIR=${0%/*}

kernel_name="Panda"

setprop persist.spectrum.kernel "$kernel_name"

# Check kernel
cat /proc/version | grep "$kernel_name" &>/dev/null || {
    # Remove this module
    touch ${MODDIR}/remove
}
