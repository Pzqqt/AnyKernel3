#!/sbin/sh

# Restore prop
setprop persist.spectrum.kernel ""
setprop persist.spectrum.profile ""
